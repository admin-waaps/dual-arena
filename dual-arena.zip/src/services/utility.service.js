


export default class UtilityService {

    constructor() { }

    showLoader() {
        
    }

    hideLoader() {
      
    }

    presentSuccessToast(msg) {
       

    }

    presentFailureToast(msg) {
       

    }

    presentWarningToast(msg) {
       
    
    }

}


