import React from 'react'
import Frame1 from '../../../assets/img/Frame1.png' 
const Index = () => {
  return (
    <img src={Frame1} alt='frame1' className=''/>
  )
}

export default Index