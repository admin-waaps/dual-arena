import "./index.css"
// import icon from './icon.png'
// import { FaCoins } from 'react-icons/fa';




function Comp3() {
    return (
        <div className="comp3">
          
        </div>
    );
}

export default Comp3;