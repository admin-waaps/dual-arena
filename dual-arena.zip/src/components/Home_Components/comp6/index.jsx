
const Comp6 = () => {
  return (
    <div className="w-[430px] mt-[] flex justify-center items-center justify-around"> 
        <a href="#" className ="w-[155px] text-[14px]"> How Does It Works </a>
        <button className="bg-[#575DE8] w-[178px] h-[38px] text-[14px] rounded-[22px]">Learn about us</button>
        </div>
  );
  }


export default Comp6