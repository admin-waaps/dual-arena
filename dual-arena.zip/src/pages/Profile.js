import React from 'react'
import ProfilePage from "../components/profile_page/profile_page"

const Profile = () => {
  return (
    <div className=' mt-[40px] h-[786px] w-full '>
      <ProfilePage/>
    </div>
  )
}

export default Profile