import React from 'react'
import PokerBreadCrum from "../components/PokerBreadCrum";
const Poker = () => {
  return (
    <div className='mt-[40px]'>
      <PokerBreadCrum />
    </div>
  )
}

export default Poker