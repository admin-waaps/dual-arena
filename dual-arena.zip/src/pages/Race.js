import React from 'react'
import RaceBreadCrum from '../components/RaceBreadCrum'

const Race = () => {
  return (
    <div className='mt-[40px]'>
      <RaceBreadCrum/>
    </div>
  )
}

export default Race