import React from 'react'
import DuelBagHeader from "../components/Duel_components/duel-arena-header/index";

const Exchange = () => {
  return (
    <div>
      <DuelBagHeader />
    </div>
  )
}

export default Exchange