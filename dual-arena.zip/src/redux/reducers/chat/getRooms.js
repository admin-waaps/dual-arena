// import NetworkService from "../../../services/network.service";

// let networkService = new NetworkService()

// const ChatReducer = function(state = 0, action){

//     switch(action.type)
//     {
//         case "SHOW_CHAT":
//             return state;

//         case "SHOW_ROOMS":
//             return async function()
//             {
//                 let res = await networkService.getRooms();
//                 console.log(res);
//             }
//         default : return state;
//     }
// }